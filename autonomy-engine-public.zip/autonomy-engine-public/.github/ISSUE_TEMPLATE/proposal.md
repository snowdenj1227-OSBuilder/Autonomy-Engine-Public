---
name: "Proposal: Pack/Adapter"
about: Suggest a vertical pack or adapter as a partner
title: "[Proposal] <Your pack/adapter name>"
labels: ["proposal"]
assignees: []
---

## Summary
Describe your proposed pack/adapter.

## Value
Who benefits and how?

## Compliance/Ethics
Any regulatory or ethical considerations?

## Contact
Email and org.
