# Code of Conduct

We are committed to a respectful, high‑signal community. By participating, you agree to:
- Be constructive, concise, and honest.
- Protect user privacy and data sovereignty.
- Avoid deceptive claims and undisclosed conflicts.

Reports: conduct@autonomyengine.io
